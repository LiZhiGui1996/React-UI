/* ============================================================================
 * qt-bridge.js —— RTestBackend 正式通信适配层（React ↔ QWebChannel ↔ Qt）
 *
 * 分层 API：window.RTestBackend = {
 *     device:      { connect(), disconnect(), getStatus() }
 *     acquisition: { start(), stop(), getState() }
 *     realtime:    { subscribe(fn), frameCount() }   // U1..U3/L1..L3 + tsMs
 *     file:        { refresh(), getList(), download(name), delete(name), on*(fn) }
 *     event:       { getEvents(page, pageSize, like, minLevel) }
 *     system:      { getVersion(), getStatus() }
 *     calib/test:  { call(method, payloadJson) }      // 渐进接入
 * }
 * 兼容保留：window.qtBridge / rtestActions / __rtestOnQtData（POC 机制）
 * 浏览器环境（无 qt.webChannelTransport）：整层不注入，React 走原模拟逻辑
 * ==========================================================================*/
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    if (typeof qt === 'undefined' || !qt.webChannelTransport) {
      console.info('[RTestBackend] 浏览器环境，Qt 桥不激活');
      return;
    }

    // 软件渲染环境优化：禁用装饰动画（心跳点/自旋图标等持续重绘源）
    document.documentElement.classList.add('qt-webui-software-render');

    new QWebChannel(qt.webChannelTransport, function (channel) {
      var be = channel.objects.rtestBackend;
      window.qtBridge = be;
      window.__qtBridgeReady = true;
      window.__qtBridgeStats = { frames: 0, lastTs: 0, calls: [], readyAt: Date.now() };

      //---- 实时数据订阅表（多消费者）----
      var dataSubs = [];
      function notifyData(d) {
        for (var i = 0; i < dataSubs.length; i++) {
          try { dataSubs[i](d); } catch (e) { console.error(e); }
        }
      }

      //---- Qt → React 信号 ----
      be.realTimeData.connect(function (u1, u2, u3, l1, l2, l3, tsMs) {
        var s = window.__qtBridgeStats;
        s.frames += 1;
        s.lastTs = tsMs;
        var detail = { u1: u1, u2: u2, u3: u3, l1: l1, l2: l2, l3: l3, tsMs: tsMs };
        if (typeof window.__rtestOnQtData === 'function') {
          try { window.__rtestOnQtData(detail); } catch (e) { console.error(e); }
        } else {
          window.__rtestQtQueue = window.__rtestQtQueue || [];
          window.__rtestQtQueue.push(detail);
          if (window.__rtestQtQueue.length > 10) window.__rtestQtQueue.shift();
        }
        notifyData(detail);
      });
      be.connectionStateChanged.connect(function (on, text) {
        window.dispatchEvent(new CustomEvent('rtest-connection', { detail: { connected: on, text: text } }));
      });
      be.acqStateChanged.connect(function (on) {
        window.dispatchEvent(new CustomEvent('rtest-acq', { detail: { acquiring: on } }));
      });
      be.faultReceived.connect(function (code, level, module, info) {
        window.dispatchEvent(new CustomEvent('rtest-fault', {
          detail: { code: code, level: level, module: module, info: info }
        }));
      });
      be.fileListUpdated.connect(function (count, sdFreeKB, tsv) {
        window.dispatchEvent(new CustomEvent('rtest-filelist', {
          detail: { count: count, sdFreeKB: sdFreeKB, tsv: tsv }
        }));
      });
      be.downloadProgress.connect(function (name, bytes, total) {
        window.dispatchEvent(new CustomEvent('rtest-dl-progress', {
          detail: { name: name, bytes: bytes, total: total }
        }));
      });
      be.downloadFinished.connect(function (name, ok, info) {
        window.dispatchEvent(new CustomEvent('rtest-dl-finished', {
          detail: { name: name, ok: ok, info: info }
        }));
      });
      be.fileDeleted.connect(function (name, ok) {
        window.dispatchEvent(new CustomEvent('rtest-file-deleted', { detail: { name: name, ok: ok } }));
      });
      be.log.connect(function (m) { console.info('[backend]', m); });

      //---- React → Qt（Q_INVOKABLE 代理 + 诊断计数）----
      function inv(fn) {
        return function () {
          window.__qtBridgeStats.calls.push({ name: fn, at: Date.now() });
          if (window.__qtBridgeStats.calls.length > 200) window.__qtBridgeStats.calls.shift();
          return be[fn].apply(be, arguments);
        };
      }

      //---- 正式分层 API ----
      window.RTestBackend = {
        device: {
          connect:    inv('connectDevice'),
          disconnect: inv('disconnectDevice'),
          getStatus:  inv('getDeviceStatus'),
          onConnectionState: function (fn) { be.connectionStateChanged.connect(function (c, s) { fn({ connected: c, stateText: s }); }); }
        },
        acquisition: {
          start:     inv('startAcquisition'),
          stop:      inv('stopAcquisition'),
          getState:  inv('getAcquisitionState')
        },
        realtime: {
          subscribe:  function (fn) { dataSubs.push(fn); return function () {
            var i = dataSubs.indexOf(fn); if (i >= 0) dataSubs.splice(i, 1);
          }; },
          frameCount: function () { return window.__qtBridgeStats.frames; }
        },
        file: {
          refresh:       inv('refreshFileList'),
          getList:       inv('getFileList'),
          download:      inv('downloadFile'),
          deleteFile:    inv('deleteFile'),
          onListUpdated: function (fn) { be.fileListUpdated.connect(function (c, kb, tsv) { fn({ count: c, sdFreeKB: kb, tsv: tsv }); }); },
          onTsv:         function (fn) { be.fileListTsv.connect(function (tsv) { fn(tsv); }); },
          onProgress:    function (fn) { be.downloadProgress.connect(function (n, b, t) { fn({ name: n, bytes: b, total: t }); }); },
          onFinished:    function (fn) { be.downloadFinished.connect(function (n, ok, info) { fn({ name: n, ok: ok, info: info }); }); },
          onDeleted:     function (fn) { be.fileDeleted.connect(function (n, ok) { fn({ name: n, ok: ok }); }); }
        },
        event: {
          getEvents: inv('getEvents')
        },
        system: {
          getVersion: inv('getVersion'),
          getStatus:  inv('getSystemStatus')
        },
        calib: { call: inv('calibApi') },
        pickSavePath: inv('pickSavePath'),
        saveTextFile: inv('saveTextFile'),
        startWindowDrag: inv('startWindowDrag'),
        startWindowResize: inv('startWindowResize'),
        pickOpenFile: function (kind, filter) { window.RTestBackend.pickOpenFile(kind, filter); },
        onOpenFilePicked: function (fn) { var sig = (window.RTestBackend && window.RTestBackend.openFilePicked) || (be && be.openFilePicked); if (sig && sig.connect) sig.connect(function (k, p) { fn({ kind: k, path: p }); }); },
        readTextFile: inv('readTextFile'),
        test:  { call: inv('testApi') },
        ping:  inv('ping'),
        window: {
          minimize:       inv('windowMinimize'),
          toggleMaximize: inv('windowToggleMaximize'),
          close:          inv('windowClose')
        }
      };

      // POC 兼容
      window.rtestActions = {
        connect:    function () { window.RTestBackend.device.connect(); },
        disconnect: function () { window.RTestBackend.device.disconnect(); },
        start:      function () { window.RTestBackend.acquisition.start(); },
        stop:       function () { window.RTestBackend.acquisition.stop(); },
        ping:       function () { be.ping('hello-from-react'); }
      };

      //---- 正式状态栏（仅 Qt 环境注入；浏览器 UI 零影响）----
      var bar = document.createElement('div');
      bar.id = 'qtPocBar';
      bar.style.cssText =
        'position:fixed;right:12px;bottom:12px;z-index:99999;display:flex;gap:8px;align-items:center;' +
        'padding:8px 10px;border-radius:10px;background:#0e141f;border:1px solid #1e293b;' +
        'font:12px/1.4 Consolas,monospace;color:#cbd5e1;box-shadow:0 4px 16px rgba(0,0,0,.5)';
      bar.innerHTML =
        '<span id="qtPocLink" style="width:10px;height:10px;border-radius:99px;background:#64748b;display:inline-block"></span>' +
        '<span id="qtPocAcq" style="min-width:56px;color:#94a3b8">STOPPED</span>' +
        '<span id="qtPocFrames" style="min-width:96px;color:#38bdf8">0 frames</span>';
      ['connect', 'start', 'stop', 'disconnect'].forEach(function (name) {
        var b = document.createElement('button');
        b.textContent = name.toUpperCase();
        b.style.cssText =
          'padding:4px 10px;border-radius:6px;border:1px solid #1e293b;background:#0284c7;' +
          'color:#fff;font:600 11px Consolas,monospace;cursor:pointer';
        if (name === 'disconnect' || name === 'stop') {
          b.style.background = 'transparent';
          b.style.color = name === 'stop' ? '#fbbf24' : '#fb7185';
          b.style.borderColor = name === 'stop' ? '#d97706' : '#e11d48';
        }
        b.addEventListener('click', function () {
          if (name === 'connect') window.RTestBackend.device.connect();
          else window.RTestBackend.acquisition[name]();
        });
        bar.appendChild(b);
      });
    
      //---- 默认不自动连接：由 S01 通信方式按钮（WiFi/蓝牙）点击触发 ----
      console.info('[RTestBackend] 正式桥已就绪（等待通信方式选择）');
      window.dispatchEvent(new CustomEvent('rtest-bridge-ready'));
    });
  });
})();
