import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { getThemeTokens } from '../utils/themeStyles';
import { S11_FileDownloadScreen } from './S11_FileDownloadScreen';
import { S12_EventLogScreen } from './S12_EventLogScreen';
import { S13_MachineConnectScreen } from './S13_MachineConnectScreen';
import {
  Lock,
  LogIn,
  UserPlus,
  LogOut,
  DownloadCloud,
  ListFilter,
  Wrench,
  ShieldCheck,
  User,
  ChevronRight,
  Network,
} from 'lucide-react';

type AdvancedTab = 'menu' | 'files' | 'events' | 'machine';

/**
 * 高阶功能（需求：文件下载 / 事件记录 / 标定 整合，需登录后操作）
 * - 预置管理员 admin / 123456；注册新用户默认"操作员"权限
 * - 标定软件入口按当前测量方式（接触式/非接触式）进入对应标定软件
 */
export const AdvancedScreen: React.FC = () => {
  const { theme, measurementMode,
    currentUser,
    login,
    register,
    logout,
    setAppMode,
  } = useApp() as any;
  const tokens = getThemeTokens(theme);

  const isLight = theme === 'light-metrology';
  const [tab, setTab] = useState<AdvancedTab>('menu');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [hint, setHint] = useState<{ ok: boolean; msg: string } | null>(null);

  const cardStyle = {
    backgroundColor: tokens.cardBg,
    borderColor: tokens.borderColor,
  };

  const handleLogin = () => {
    const r = login(username.trim(), password);
    setHint(r);
    if (r.ok) {
      setPassword('');
      setHint(null);
    }
  };

  const handleRegister = () => {
    if (password !== confirmPwd) {
      setHint({ ok: false, msg: '两次输入的密码不一致' });
      return;
    }
    const r = register(username.trim(), password);
    setHint(r);
    if (r.ok) {
      setPassword('');
      setConfirmPwd('');
      setTimeout(() => setHint(null), 3000);
    }
  };

  const roleBadge = (role: string) => (
    <span
      className={`px-2 py-0.5 rounded text-[12px] font-semibold border ${
        role === 'admin'
          ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
          : 'bg-sky-500/15 text-sky-400 border-sky-500/30'
      }`}
    >
      {role === 'admin' ? '管理员' : '操作员'}
    </span>
  );

  /* ---------- 未登录：登录 / 注册 ---------- */
  if (!currentUser) {
    return (
      <div className="flex-1 flex items-center justify-center p-6 overflow-auto">
        <div
          className="w-full max-w-md rounded-xl border p-6 shadow-2xl"
          style={cardStyle}
        >
          <div className="flex items-center gap-2 mb-1">
            <Lock className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-bold" style={{ color: tokens.titleColor }}>
              高阶功能 · {mode === 'login' ? '登录' : '注册新用户'}
            </h2>
          </div>
          <p className="text-[12px] mb-4" style={{ color: tokens.mutedColor }}>
            文件下载 / 事件记录 / 标定软件 需要授权账户访问
          </p>

          <div className="flex flex-col gap-3">
            <div>
              <label className="text-[12px] block mb-1" style={{ color: tokens.mutedColor }}>用户名</label>
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="请输入用户名"
                className={`w-full px-3 py-1.5 rounded border text-sm font-mono-num ${tokens.inputClass}`}
              />
            </div>
            <div>
              <label className="text-[12px] block mb-1" style={{ color: tokens.mutedColor }}>密码</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="请输入密码"
                onKeyDown={(e) => { if (e.key === 'Enter' && mode === 'login') handleLogin(); }}
                className={`w-full px-3 py-1.5 rounded border text-sm font-mono-num ${tokens.inputClass}`}
              />
            </div>
            {mode === 'register' && (
              <div>
                <label className="text-[12px] block mb-1" style={{ color: tokens.mutedColor }}>确认密码</label>
                <input
                  type="password"
                  value={confirmPwd}
                  onChange={(e) => setConfirmPwd(e.target.value)}
                  placeholder="再次输入密码"
                  className={`w-full px-3 py-1.5 rounded border text-sm font-mono-num ${tokens.inputClass}`}
                />
              </div>
            )}

            {hint && (
              <div
                className={`px-3 py-1.5 rounded text-[12px] border ${
                  hint.ok
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                }`}
              >
                {hint.msg}
              </div>
            )}

            <button
              onClick={mode === 'login' ? handleLogin : handleRegister}
              className="w-full py-2 rounded bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {mode === 'login' ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
              {mode === 'login' ? '登录' : '注册并登录'}
            </button>

            <button
              onClick={() => {
                setMode(mode === 'login' ? 'register' : 'login');
                setHint(null);
                setConfirmPwd('');
              }}
              className="text-[12px] text-sky-400 hover:text-sky-300 text-center cursor-pointer"
            >
              {mode === 'login' ? '没有账户？注册新用户（操作员权限）' : '返回登录'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ---------- 已登录：功能整合区 ---------- */
  if (tab === 'files') {
    return (
      <div className="flex-1 flex flex-col min-h-0">
        <div className="px-4 py-2 flex items-center gap-3 border-b shrink-0" style={{ borderColor: tokens.dividerColor }}>
          <button
            onClick={() => setTab('menu')}
            className="px-3 py-1 rounded text-[12px] border flex items-center gap-1 transition-colors cursor-pointer"
            style={cardStyle}
          >
            ← 返回高阶功能
          </button>
          <span className="text-xs" style={{ color: tokens.mutedColor }}>
            当前用户：{currentUser.username} · {currentUser.role === 'admin' ? '管理员' : '操作员'}
          </span>
        </div>
        <S11_FileDownloadScreen />
      </div>
    );
  }

  if (tab === 'events') {
    return (
      <div className="flex-1 flex flex-col min-h-0">
        <div className="px-4 py-2 flex items-center gap-3 border-b shrink-0" style={{ borderColor: tokens.dividerColor }}>
          <button
            onClick={() => setTab('menu')}
            className="px-3 py-1 rounded text-[12px] border flex items-center gap-1 transition-colors cursor-pointer"
            style={cardStyle}
          >
            ← 返回高阶功能
          </button>
          <span className="text-xs" style={{ color: tokens.mutedColor }}>
            当前用户：{currentUser.username} · {currentUser.role === 'admin' ? '管理员' : '操作员'}
          </span>
        </div>
        <S12_EventLogScreen />
      </div>
    );
  }

  if (tab === 'machine') {
    return (
      <div className="flex-1 flex flex-col min-h-0">
        <div className="px-4 py-2 flex items-center gap-3 border-b shrink-0" style={{ borderColor: tokens.dividerColor }}>
          <button
            onClick={() => setTab('menu')}
            className="px-3 py-1 rounded text-[12px] border flex items-center gap-1 transition-colors cursor-pointer"
            style={cardStyle}
          >
            ← 返回高阶功能
          </button>
          <span className="text-xs" style={{ color: tokens.mutedColor }}>
            当前用户：{currentUser.username} · {currentUser.role === 'admin' ? '管理员' : '操作员'}
          </span>
        </div>
        <S13_MachineConnectScreen />
      </div>
    );
  }

  /* ---------- 功能菜单 ---------- */
  const entries: Array<{
    key: string;
    title: string;
    desc: string;
    icon: React.ReactNode;
    onClick: () => void;
  }> = [
    {
      key: 'files',
      title: '文件下载',
      desc: '采集仪 SD 卡文件列表 / 下载 / 删除',
      icon: <DownloadCloud className="w-7 h-7 text-sky-400" />,
      onClick: () => setTab('files'),
    },
    {
      key: 'events',
      title: '事件记录',
      desc: '运行 / 连接 / 故障 / 操作 审计日志查询与导出',
      icon: <ListFilter className="w-7 h-7 text-indigo-400" />,
      onClick: () => setTab('events'),
    },
    {
      key: 'machine',
      title: '机床连接',
      desc: '机床直连功能接口（FANUC / 西门子 / 海德汉 / 华中数控）',
      icon: <Network className="w-7 h-7 text-emerald-400" />,
      onClick: () => setTab('machine'),
    },
    {
      key: 'calib',
      title: `标定软件（${measurementMode === 'contact' ? '接触式' : '非接触式'}）`,
      desc: '集成到当前测量方式对应的标定工作台',
      icon: <Wrench className="w-7 h-7 text-amber-400" />,
      onClick: () =>
        setAppMode(measurementMode === 'contact' ? 'calib-software-contact' : 'calib-software-noncontact'),
    },
  ];

  return (
    <div className="flex-1 flex flex-col p-6 overflow-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-emerald-400" />
          <h2 className="text-lg font-bold" style={{ color: tokens.titleColor }}>
            高阶功能
          </h2>
          <span className="text-[12px]" style={{ color: tokens.mutedColor }}>
            （授权账户已登录）
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded border" style={cardStyle}>
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[12px] font-medium" style={{ color: tokens.bodyColor }}>
              {currentUser.username}
            </span>
            {roleBadge(currentUser.role)}
          </div>
          <button
            onClick={() => {
              logout();
              setTab('menu');
            }}
            className="px-3 py-1 rounded text-[12px] border flex items-center gap-1 transition-colors cursor-pointer"
            style={cardStyle}
          >
            <LogOut className="w-3.5 h-3.5" />
            退出登录
          </button>
        </div>
      </div>

      {/* Entries */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {entries.map((e) => (
          <button
            key={e.key}
            onClick={e.onClick}
            className={`group text-left p-5 rounded-xl border flex flex-col gap-3 cursor-pointer transition-all hover:-translate-y-1 hover:shadow-xl ${isLight ? 'bg-white' : ''}`}
            style={cardStyle}
          >
            <div
              className={`w-14 h-14 rounded-lg flex items-center justify-center border ${
                isLight ? 'bg-slate-100' : 'bg-white/5'
              } group-hover:scale-105 transition-transform`}
            >
              {e.icon}
            </div>
            <div>
              <div className="text-base font-bold mb-1 group-hover:text-sky-400 transition-colors" style={{ color: tokens.titleColor }}>
                {e.title}
              </div>
              <div className="text-[12px]" style={{ color: tokens.mutedColor }}>
                {e.desc}
              </div>
            </div>
            <ChevronRight className="w-4 h-4 self-end opacity-40 group-hover:opacity-100 group-hover:text-sky-400 transition-all" />
          </button>
        ))}
      </div>
    </div>
  );
};
