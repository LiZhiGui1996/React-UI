import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';

/**
 * AutoSelect —— 自绘下拉选择（替代原生 <select>）
 * 背景：Qt WebEngine 在页面缩放（zoomFactor≠1）时，原生 select 弹窗
 *       定位/尺寸计算错误（飞出控件位置、尺寸错乱）。
 *       自绘下拉是页面内元素，位置/尺寸/命中全部正确，且样式可完全定制。
 *
 * props:
 *   value        当前值（对应 option.value）
 *   options      选项：字符串数组 或 {value,label} 对象数组（两者可混用）
 *   onChange(v)  选择回调（返回 option.value）
 *   disabled     禁用
 *   className    触发按钮附加样式
 *   width        下拉列表最小宽度（默认撑满触发器）
 *
 * 注意：options 若为对象数组，触发器显示 option.label（React #31 教训：
 *       绝不能把 option 对象本身作为 React child 渲染，否则整树崩溃黑屏）。
 */
type AutoOption = string | { value: string; label: string };

const normOption = (o: AutoOption): { value: string; label: string } =>
  typeof o === 'string' ? { value: o, label: o } : { value: o.value, label: o.label ?? o.value };

export const AutoSelect: React.FC<{
  value: string;
  options: AutoOption[];
  onChange: (v: string) => void;
  disabled?: boolean;
  className?: string;
  width?: number;
}> = ({ value, options, onChange, disabled, className, width }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const normalized = options.map(normOption);
  const current = normalized.find((o) => o.value === value);

  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h, true);
    return () => document.removeEventListener('mousedown', h, true);
  }, [open]);

  return (
    <div ref={ref} className="relative" style={width ? { minWidth: width } : undefined}>
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen(!open)}
        className={`flex items-center justify-between gap-1.5 px-2 py-0.5 rounded border text-xs font-semibold transition-colors ${
          disabled ? 'opacity-85 cursor-default' : 'cursor-pointer'
        } ${className ?? ''}`}
      >
        <span>{current?.label ?? value}</span>
        <ChevronDown className={`w-3 h-3 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div
          className="absolute left-0 top-full mt-1 z-50 rounded-md border py-1 shadow-2xl min-w-full"
          style={{
            backgroundColor: '#141a24',
            borderColor: '#2a3648',
            minWidth: width ? undefined : '100%',
          }}
        >
          {normalized.map((o) => (
            <div
              key={o.value}
              onClick={() => {
                onChange(o.value);
                setOpen(false);
              }}
              className={`px-3 py-1 text-xs cursor-pointer whitespace-nowrap flex items-center justify-between ${
                o.value === value ? 'bg-sky-500/25 text-sky-300 font-semibold' : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              <span>{o.label}</span>
              {o.value === value && <Check className="w-3 h-3 shrink-0" />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
