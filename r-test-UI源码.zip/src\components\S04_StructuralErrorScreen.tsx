import React, { useState, useEffect } from 'react';
import { AutoSelect } from './AutoSelect';
import { useApp } from '../context/AppContext';
import { useRealtime } from '../realtime/realtimeStore';
import { MeasurementPoint } from '../types';
import { INITIAL_MEASUREMENT_POINTS } from '../data/mockData';
import { DEFAULT_RTCP_PARAMS, DEFAULT_NON_RTCP_PARAMS, buildRtcpProgram, buildNonRtcpProgram, nonRtcpAxisMeta, RtcpParams, NonRtcpParams, NcAxis } from '../data/ncTemplates';
import { getThemeTokens } from '../utils/themeStyles';
import { InteractiveCurveBox } from './InteractiveCurveBox';
import { 
  Lock, 
  Unlock, 
  FileCode, 
  Play, 
  Square, 
  Plus, 
  Hand, 
  Save, 
  XCircle, 
  Target, 
  Info,
  CheckCircle2,
  Calendar,
  Layers,
  Table as TableIcon,
  LineChart
} from 'lucide-react';

export const S04_StructuralErrorScreen: React.FC = () => {
  const { 
    measurementMode, 
    recordOrigin, 
    showToast, 
    errorSubTab, 
    setErrorSubTab,
    theme,
    setWorkflowStepIndex,
    setCurrentMainTab
  } = useApp();

  /* 实时数据（独立 store：仅本组件随数据重渲染） */
  const { sensorData, voltageHistory, displacementHistory, sampleCount } = useRealtime();

  const isLight = theme === 'light-metrology';
  const tokens = getThemeTokens(theme);

  // Top Parameters Row
  const [isParamLocked, setIsParamLocked] = useState(true);
  const [machineId, setMachineId] = useState('VMG-05');
  const [machineModel, setMachineModel] = useState('五轴联动加工中心');
  const [isBaseRotated, setIsBaseRotated] = useState('否');
  const [axisName, setAxisName] = useState('C轴');
  const [measureTime, setMeasureTime] = useState('2026-09-14 10:30');
  const [operator, setOperator] = useState('张工');
  const [isRTCP, setIsRTCP] = useState('否');

  // NC 程序参数（资料：测量轨迹(2).zip 宏模板；界面参数值 → #变量行）
  const [rtcpParams, setRtcpParams] = useState<RtcpParams>(DEFAULT_RTCP_PARAMS);
  const [nonRtcpParams, setNonRtcpParams] = useState<NonRtcpParams>(DEFAULT_NON_RTCP_PARAMS);
  const ncAxis = axisName as NcAxis;
  const isRTCPMode = isRTCP === '是';

  // Angle Parameters
  const [startAngle, setStartAngle] = useState(0);
  const [endAngle, setEndAngle] = useState(360);
  const [stepAngle, setStepAngle] = useState(20);
  const [threshold, setThreshold] = useState(0.01);
  const [intervalTime, setIntervalTime] = useState(5);

  const [points, setPoints] = useState<MeasurementPoint[]>(INITIAL_MEASUREMENT_POINTS);
  const [selectedPointIndex, setSelectedPointIndex] = useState<number>(0);
  const [viewMode, setViewMode] = useState<'table' | 'curve'>('table');

  // Auto Measurement Simulation
  const [isAutoMeasuring, setIsAutoMeasuring] = useState(false);
  const [currentMeasuringIndex, setCurrentMeasuringIndex] = useState<number | null>(null);

  // Save Modal
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [saveFileName, setSaveFileName] = useState('');

  // Calculate total points
  const pointsCount = Math.floor(Math.abs(endAngle - startAngle) / (stepAngle || 20)) + (endAngle % stepAngle === 0 ? 0 : 1);

  const handleGeneratePoints = () => {
    const newPoints: MeasurementPoint[] = [];
    const count = Math.max(1, Math.floor((endAngle - startAngle) / stepAngle));
    for (let i = 0; i <= count; i++) {
      const angle = startAngle + i * stepAngle;
      if (angle > endAngle) break;
      const rad = (angle * Math.PI) / 180;
      const x = Number((12.5000 + 0.0085 * Math.sin(rad)).toFixed(4));
      const y = Number((-0.0200 + 0.0072 * Math.cos(rad)).toFixed(4));
      const z = Number((3.3090 + 0.0035 * Math.sin(2 * rad)).toFixed(4));
      newPoints.push({
        index: i + 1,
        angle,
        x,
        y,
        z,
        dx: Number((x - 12.5000).toFixed(4)),
        dy: Number((y - (-0.0200)).toFixed(4)),
        dz: Number((z - 3.3090).toFixed(4)),
      });
    }
    setPoints(newPoints);
    showToast(`已按参数生成 ${newPoints.length} 个测量点`);
  };

  // Run auto measurement simulation
  useEffect(() => {
    if (!isAutoMeasuring) return;
    let currentIdx = 0;
    const timer = setInterval(() => {
      if (currentIdx < points.length) {
        setCurrentMeasuringIndex(currentIdx);
        currentIdx++;
      } else {
        setIsAutoMeasuring(false);
        setCurrentMeasuringIndex(null);
        showToast(`自动测量完成，共 ${points.length} 个测点采集完毕`);
        setWorkflowStepIndex(9); // 等待完成 / 保存
        clearInterval(timer);
      }
    }, 600);
    return () => clearInterval(timer);
  }, [isAutoMeasuring, points.length]);

  const handleStartAutoMeasure = () => {
    if (!isParamLocked) {
      showToast('请先点击右上角【确定】锁定测量任务参数！');
      return;
    }
    if (isAutoMeasuring) {
      setIsAutoMeasuring(false);
      setCurrentMeasuringIndex(null);
      showToast('自动测量已中止');
    } else {
      setIsAutoMeasuring(true);
      showToast('自动测量已启动，机床按角度间隔依次采集...');
      setWorkflowStepIndex(8); // 自动测量
    }
  };

  // NC 程序生成：按 RTCP/非RTCP 模板代入界面参数（资料：测量轨迹(2).zip）
  const buildNCProgram = (): string => {
    if (isRTCPMode) return buildRtcpProgram(ncAxis, rtcpParams);
    return buildNonRtcpProgram(ncAxis, nonRtcpParams);
  };

  const handleExportNC = async () => {
    const nc = buildNCProgram();
    const mode = isRTCPMode ? 'RTCP' : 'NONRTCP';
    const defaultName = `NC_${machineId}_${axisName.replace('轴', '')}_${mode}.nc`;
    const qt: any = (window as any).RTestBackend;
    if (qt?.pickSavePath && qt?.saveTextFile) {
      const path = await qt.pickSavePath(defaultName);   /* QWebChannel 异步：返回所选路径（取消为空） */
      if (path) {
        const ok = await qt.saveTextFile(path, nc);
        showToast(ok ? `NC 程序已保存：${path}` : 'NC 程序保存失败');
        if (ok) setWorkflowStepIndex(6); // 导出NC程序
      }
      return;
    }
    // 浏览器回退：Blob 下载
    const blob = new Blob([nc], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = defaultName;
    a.click();
    setWorkflowStepIndex(6);
  };

  const handleManualMeasure = () => {
    showToast(`手动测量点 #${selectedPointIndex + 1} 采集完成：X=${sensorData.x.toFixed(4)}, Y=${sensorData.y.toFixed(4)}, Z=${sensorData.z.toFixed(4)}`);
  };

  const handleSaveReport = () => {
    const finalName = saveFileName.trim() || `${machineId}_${axisName}_${new Date().toISOString().slice(0,10)}.dat`;
    // 文件头：测量参数（含 是否是RTCP），同步写入保存文件
    const header = [
      `% MEASURE HEADER`,
      `% 测量方式: ${measurementMode === 'contact' ? '接触式' : '非接触式'}`,
      `% 机床编号: ${machineId}`,
      `% 机床型号: ${machineModel}`,
      `% 测量座旋转: ${isBaseRotated}`,
      `% 转动轴: ${axisName}`,
      `% 是否是RTCP: ${isRTCP}`,
      `% 时间: ${measureTime}`,
      `% 测量人员: ${operator}`,
      `% 测点数: ${points.length}`,
      `%`,
    ].join('\n');
    const dataRows = points
      .map((p) =>
        [
          p.angle.toFixed(2),
          p.x.toFixed(6),
          p.y.toFixed(6),
          p.z.toFixed(6),
          p.dx.toFixed(6),
          p.dy.toFixed(6),
          p.dz.toFixed(6),
        ].join('\t')
      )
      .join('\n');
    const content = [header, dataRows].filter(Boolean).join('\n');

    const qtBackend = (window as any).RTestBackend;
    if (qtBackend) {
      // Qt 宿主：经 Backend 落盘到 exe/Data/<finalName>
      qtBackend.test.call('saveReport', JSON.stringify({ fileName: finalName, isRTCP, content }));
    } else {
      // 浏览器预览：本地下载
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = finalName;
      a.click();
    }
    setShowSaveModal(false);
    showToast(`测量数据已保存：${finalName}（RTCP: ${isRTCP}）`);
    setWorkflowStepIndex(10); // 保存
    setTimeout(() => {
      setWorkflowStepIndex(11); // 采集完成
      setCurrentMainTab('history-report');
    }, 800);
  };

  return (
    <div className="flex-1 flex flex-col gap-2.5 p-3 overflow-hidden select-none">
      {/* 1. Top Parameters Row (Single Dense Row with Lock/Unlock) */}
      <div 
        className="px-3 py-2 rounded-lg border flex items-center justify-between gap-3 text-xs shrink-0 transition-colors shadow-sm"
        style={{
          backgroundColor: tokens.cardBg,
          borderColor: tokens.borderColor,
        }}
      >
        <div className="flex items-center gap-3.5 flex-wrap flex-1">
          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>测量方式:</span>
            <span className="font-semibold text-sky-400 font-sans">
              {measurementMode === 'contact' ? '接触式' : '非接触式'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>机床编号:</span>
            <input
              type="text"
              value={machineId}
              disabled={isParamLocked}
              onChange={(e) => setMachineId(e.target.value)}
              placeholder="请输入机床编号"
              className={`w-24 px-2 py-0.5 rounded border text-xs disabled:opacity-85 ${tokens.inputClass}`}
            />
          </div>

          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>机床型号:</span>
            <input
              type="text"
              value={machineModel}
              disabled={isParamLocked}
              onChange={(e) => setMachineModel(e.target.value)}
              className={`w-36 px-2 py-0.5 rounded border text-xs disabled:opacity-85 ${tokens.inputClass}`}
            />
          </div>

          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>测量座旋转:</span>
            <AutoSelect value={ isBaseRotated } options={ ['否', '是'] } disabled={ isParamLocked } onChange={ (v) => setIsBaseRotated(v) } className="w-20 bg-black/40 border-white/10" />
          </div>

          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>转动轴:</span>
            <AutoSelect
              value={axisName}
              options={['A轴', 'B轴', 'C轴']}
              disabled={isParamLocked}
              onChange={(v) => setAxisName(v)}
              className="w-20 bg-black/40 border-white/10"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>是否是RTCP:</span>
            <AutoSelect
              value={isRTCP}
              options={['是', '否']}
              disabled={isParamLocked}
              onChange={(v) => setIsRTCP(v)}
              className="w-16 bg-black/40 border-white/10"
            />
          </div>
          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>时间:</span>
            <input
              type="text"
              value={measureTime}
              disabled={isParamLocked}
              onChange={(e) => setMeasureTime(e.target.value)}
              className={`w-32 px-2 py-0.5 rounded border font-mono-num text-[17px] disabled:opacity-85 ${tokens.inputClass}`}
            />
          </div>


          <div className="flex items-center gap-1.5">
            <span style={{ color: tokens.mutedColor }}>测量人员:</span>
            <input
              type="text"
              value={operator}
              disabled={isParamLocked}
              onChange={(e) => setOperator(e.target.value)}
              className={`w-16 px-2 py-0.5 rounded border text-xs disabled:opacity-85 ${tokens.inputClass}`}
            />
          </div>
        </div>

        {/* Lock/Unlock Toggle */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => {
              setIsParamLocked(!isParamLocked);
              showToast(isParamLocked ? '参数已解锁，可编辑机床与任务信息' : '参数已锁定保存');
            }}
            className={`px-3 py-1 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isParamLocked
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-600/30'
                : 'bg-amber-600 hover:bg-amber-500 text-white'
            }`}
          >
            {isParamLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{isParamLocked ? '修改' : '确定'}</span>
          </button>
        </div>
      </div>

      {/* 2. Main Content Split: Left (Parameters + Table) | Right (Sensor + Buttons) */}
      <div className="flex-1 flex gap-3 min-h-0 overflow-hidden">
        {/* Middle Left: Sub-tabs, Angle Parameters Grid, Measurement Points Table */}
        <div 
          className="flex-1 rounded-lg border flex flex-col min-w-0 transition-colors shadow-sm overflow-hidden"
          style={{
            backgroundColor: tokens.cardBg,
            borderColor: tokens.borderColor,
          }}
        >
          {/* Sub-tabs Header: 结构误差测量 vs 动态误差测量 */}
          <div 
            className="px-3 py-1.5 border-b flex items-center justify-between shrink-0"
            style={{
              backgroundColor: tokens.subcardBg,
              borderColor: tokens.dividerColor,
            }}
          >
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setErrorSubTab('structural')}
                className={`px-3 py-1 rounded text-xs font-semibold tracking-wide transition-colors ${
                  errorSubTab === 'structural'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'hover:text-sky-400'
                }`}
                style={errorSubTab !== 'structural' ? { color: tokens.mutedColor } : undefined}
              >
                结构误差测量
              </button>
              <button
                onClick={() => setErrorSubTab('dynamic')}
                className={`px-3 py-1 rounded text-xs font-semibold tracking-wide transition-colors ${
                  errorSubTab === 'dynamic'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'hover:text-sky-400'
                }`}
                style={errorSubTab !== 'dynamic' ? { color: tokens.mutedColor } : undefined}
              >
                动态误差测量
              </button>
            </div>

            <span className="text-[17px] font-sans" style={{ color: tokens.mutedColor }}>
              自动测量使用 • 逐点采样模式
            </span>
          </div>

          {/* Angle Parameter Grid */}
          <div 
            className="p-3 border-b flex flex-wrap items-center justify-between gap-3 text-xs shrink-0"
            style={{ borderColor: tokens.dividerColor }}
          >
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-1">
                <span style={{ color: tokens.mutedColor }}>起始角度:</span>
                <input
                  type="number"
                  value={startAngle}
                  onChange={(e) => setStartAngle(Number(e.target.value))}
                  className={`w-16 px-1.5 py-0.5 rounded border font-mono-num text-center text-xs ${tokens.inputClass}`}
                />
                <span style={{ color: tokens.mutedColor }}>°</span>
              </div>

              <div className="flex items-center gap-1">
                <span style={{ color: tokens.mutedColor }}>终止角度:</span>
                <input
                  type="number"
                  value={endAngle}
                  onChange={(e) => setEndAngle(Number(e.target.value))}
                  className={`w-16 px-1.5 py-0.5 rounded border font-mono-num text-center text-xs ${tokens.inputClass}`}
                />
                <span style={{ color: tokens.mutedColor }}>°</span>
              </div>

              <div className="flex items-center gap-1">
                <span style={{ color: tokens.mutedColor }}>间隔角度:</span>
                <input
                  type="number"
                  value={stepAngle}
                  onChange={(e) => setStepAngle(Number(e.target.value))}
                  className={`w-16 px-1.5 py-0.5 rounded border font-mono-num text-center text-xs ${tokens.inputClass}`}
                />
                <span style={{ color: tokens.mutedColor }}>°</span>
              </div>

              <div className="flex items-center gap-1">
                <span style={{ color: tokens.mutedColor }}>阈值:</span>
                <input
                  type="number"
                  step="0.001"
                  value={threshold}
                  onChange={(e) => setThreshold(Number(e.target.value))}
                  className={`w-16 px-1.5 py-0.5 rounded border font-mono-num text-center text-xs ${tokens.inputClass}`}
                />
                <span style={{ color: tokens.mutedColor }}>mm</span>
              </div>

              <div className="flex items-center gap-1">
                <span style={{ color: tokens.mutedColor }}>间隔时间:</span>
                <input
                  type="number"
                  value={intervalTime}
                  onChange={(e) => setIntervalTime(Number(e.target.value))}
                  className={`w-14 px-1.5 py-0.5 rounded border font-mono-num text-center text-xs ${tokens.inputClass}`}
                />
                <span style={{ color: tokens.mutedColor }}>s</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs font-mono-num" style={{ color: tokens.bodyColor }}>
                测量点数: <strong className="text-sky-400 font-bold">{points.length}</strong>
              </span>
              <button
                onClick={handleGeneratePoints}
                className="px-3 py-1 rounded bg-sky-600 hover:bg-sky-500 text-white font-medium text-xs transition-colors shadow-xs"
              >
                确定
              </button>
            </div>
          </div>

          {/* NC Program Parameters（资料：测量轨迹(2).zip 宏模板；RTCP/非RTCP 参数组随"是否是RTCP"切换） */}
          <div
            className="rounded-lg border p-3 shrink-0"
            style={{ backgroundColor: tokens.subcardBg, borderColor: tokens.borderColor }}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold" style={{ color: tokens.titleColor }}>
                NC 程序参数（{isRTCPMode ? 'RTCP' : `非RTCP · ${axisName}`}）
              </span>
              <span className="text-[12px] font-mono-num" style={{ color: tokens.mutedColor }}>
                模板 O8003 · 变量号与宏程序一致
              </span>
            </div>
            {isRTCPMode ? (
              <div className="grid grid-cols-3 gap-2">
                {([
                  ['起始角度', '#5', 'start'],
                  ['旋转范围 (°)', '#6', 'range'],
                  ['间隔角度 (°)', '#7', 'interval'],
                  ['停留时间 (s)', '#8', 'dwell'],
                  ['刀长号 (H)', '#9', 'toolNo'],
                  ['进给速度', '#16', 'feed'],
                ] as const).map(([label, varNo, key]) => (
                  <div key={key} className="flex items-center gap-1.5">
                    <span className="text-[12px] whitespace-nowrap" style={{ color: tokens.mutedColor }}>
                      {label} <span className="font-mono-num opacity-70">{varNo}</span>:
                    </span>
                    <input
                      type="number"
                      step="0.001"
                      value={(rtcpParams as any)[key]}
                      onChange={(e) => setRtcpParams({ ...rtcpParams, [key]: Number(e.target.value) })}
                      className={`flex-1 min-w-0 w-16 px-1.5 py-0.5 rounded border font-mono-num text-center text-xs ${tokens.inputClass}`}
                    />
                  </div>
                ))}
              </div>
            ) : (
              (() => {
                const meta = nonRtcpAxisMeta(ncAxis);
                const fields: Array<[string, string, keyof NonRtcpParams]> = [
                  [meta.label1, '#1', 'arcStart1'],
                  [meta.label2, '#2', 'arcStart2'],
                  [meta.labelC1, '#4', 'center1'],
                  [meta.labelC2, '#5', 'center2'],
                  ['圆弧角度 (°)', '#6', 'arcRange'],
                  ['停留间隔角度 (°)', '#7', 'dwellInterval'],
                  ['停留时间 (s)', '#8', 'dwell'],
                  ['进给速度', '#16', 'feed'],
                  ['角度步长 (°)', '#19', 'stepDeg'],
                  ['起始角度 (°)', '#25', 'startAngle'],
                  ['联动倍率', '#26', 'gain'],
                ];
                return (
                  <div className="grid grid-cols-3 gap-2">
                    {fields.map(([label, varNo, key]) => (
                      <div key={key} className="flex items-center gap-1.5">
                        <span className="text-[12px] whitespace-nowrap" style={{ color: tokens.mutedColor }}>
                          {label} <span className="font-mono-num opacity-70">{varNo}</span>:
                        </span>
                        <input
                          type="number"
                          step="0.001"
                          value={(nonRtcpParams as any)[key]}
                          onChange={(e) => setNonRtcpParams({ ...nonRtcpParams, [key]: Number(e.target.value) })}
                          className={`flex-1 min-w-0 w-16 px-1.5 py-0.5 rounded border font-mono-num text-center text-xs ${tokens.inputClass}`}
                        />
                      </div>
                    ))}
                  </div>
                );
              })()
            )}
          </div>


          {/* Helper Note & View Mode Switcher */}
          <div 
            className="px-3 py-1.5 text-[17px] border-b flex items-center justify-between shrink-0"
            style={{ 
              backgroundColor: tokens.subcardBg,
              borderColor: tokens.dividerColor,
              color: tokens.mutedColor 
            }}
          >
            <div className="flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span>注：此页面球心坐标为机床实测条件下的空间坐标 (X/Y/Z) 与误差残差 (dx/dy/dz)</span>
            </div>
            <div className="flex items-center gap-1 rounded p-0.5 border" style={{ borderColor: tokens.dividerColor }}>
              <button
                onClick={() => setViewMode('table')}
                className={`px-2 py-0.5 rounded text-[17px] font-medium flex items-center gap-1 transition-colors ${
                  viewMode === 'table'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'hover:text-sky-400'
                }`}
                style={viewMode !== 'table' ? { color: tokens.mutedColor } : undefined}
              >
                <TableIcon className="w-3 h-3" />
                <span>表格数据</span>
              </button>
              <button
                onClick={() => setViewMode('curve')}
                className={`px-2 py-0.5 rounded text-[17px] font-medium flex items-center gap-1 transition-colors ${
                  viewMode === 'curve'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'hover:text-sky-400'
                }`}
                style={viewMode !== 'curve' ? { color: tokens.mutedColor } : undefined}
              >
                <LineChart className="w-3 h-3" />
                <span>误差曲线 (可拖动缩放)</span>
              </button>
            </div>
          </div>

          {/* Conditional Display: 8-Column Measurement Point Table vs Interactive Curve */}
          {viewMode === 'table' ? (
            <div className="flex-1 overflow-auto min-h-0">
              <table className="w-full text-left text-xs border-collapse">
                <thead 
                  className={`sticky top-0 border-b text-[17px] font-bold select-none z-10 ${tokens.tableHeaderClass}`}
                  style={{ borderColor: tokens.borderColor }}
                >
                  <tr>
                    <th className="py-2 px-3 w-12 text-center">序号</th>
                    <th className="py-2 px-3">角度 (°)</th>
                    <th className="py-2 px-3">X (mm)</th>
                    <th className="py-2 px-3">Y (mm)</th>
                    <th className="py-2 px-3">Z (mm)</th>
                    <th className="py-2 px-3">dx (mm)</th>
                    <th className="py-2 px-3">dy (mm)</th>
                    <th className="py-2 px-3">dz (mm)</th>
                  </tr>
                </thead>
                <tbody 
                  className="divide-y font-mono-num text-[17px]"
                  style={{ borderColor: tokens.dividerColor }}
                >
                  {points.map((pt, idx) => {
                    const isMeasuringThis = currentMeasuringIndex === idx;
                    const isSelected = selectedPointIndex === idx;

                    return (
                      <tr
                        key={pt.index}
                        onClick={() => setSelectedPointIndex(idx)}
                        className={`cursor-pointer transition-colors ${
                          isMeasuringThis
                            ? 'bg-amber-500/20 text-amber-300 font-bold'
                            : isSelected
                              ? isLight ? 'bg-sky-100 text-sky-900 font-semibold' : 'bg-sky-500/20 text-sky-200'
                              : idx % 2 === 0
                                ? isLight ? 'bg-white' : 'bg-transparent'
                                : isLight ? 'bg-slate-50' : 'bg-black/15'
                        } hover:bg-sky-500/10`}
                      >
                        <td className="py-1.5 px-3 text-center font-bold" style={{ color: tokens.mutedColor }}>
                          {isMeasuringThis ? '▶' : pt.index}
                        </td>
                        <td className="py-1.5 px-3 font-semibold" style={{ color: tokens.bodyColor }}>
                          {pt.angle.toFixed(1)}°
                        </td>
                        <td className="py-1.5 px-3" style={{ color: tokens.titleColor }}>{pt.x.toFixed(4)}</td>
                        <td className="py-1.5 px-3" style={{ color: tokens.titleColor }}>{pt.y.toFixed(4)}</td>
                        <td className="py-1.5 px-3" style={{ color: tokens.titleColor }}>{pt.z.toFixed(4)}</td>
                        <td className={`py-1.5 px-3 ${pt.dx >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {pt.dx >= 0 ? `+${pt.dx.toFixed(4)}` : pt.dx.toFixed(4)}
                        </td>
                        <td className={`py-1.5 px-3 ${pt.dy >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {pt.dy >= 0 ? `+${pt.dy.toFixed(4)}` : pt.dy.toFixed(4)}
                        </td>
                        <td className={`py-1.5 px-3 ${pt.dz >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {pt.dz >= 0 ? `+${pt.dz.toFixed(4)}` : pt.dz.toFixed(4)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex-1 flex flex-col p-3 gap-2 min-h-0 overflow-hidden">
              {/* Curve Header & Legend */}
              <div className="flex items-center justify-between text-xs pb-1 border-b" style={{ borderColor: tokens.dividerColor }}>
                <div className="flex items-center gap-3">
                  <span className="font-semibold" style={{ color: tokens.titleColor }}>空间误差走势曲线 (θ ∈ [{startAngle}°, {endAngle}°])</span>
                  <div className="flex items-center gap-3 text-[17px] font-mono-num">
                    <span className="flex items-center gap-1 text-rose-400">
                      <span className="w-2.5 h-0.5 bg-rose-500 inline-block rounded"></span>
                      dx (X轴偏差)
                    </span>
                    <span className="flex items-center gap-1 text-emerald-400">
                      <span className="w-2.5 h-0.5 bg-emerald-500 inline-block rounded"></span>
                      dy (Y轴偏差)
                    </span>
                    <span className="flex items-center gap-1 text-sky-400">
                      <span className="w-2.5 h-0.5 bg-sky-500 inline-block rounded"></span>
                      dz (Z轴跳动)
                    </span>
                  </div>
                </div>
                <div className="text-[17px] font-mono-num" style={{ color: tokens.mutedColor }}>
                  当前基准零位: ±{threshold} mm 阈值
                </div>
              </div>

              {/* Interactive Draggable & Zoomable Curve Box */}
              <InteractiveCurveBox className="flex-1 rounded border border-white/10 overflow-hidden p-2">
                <svg className="w-full h-full" viewBox="0 0 800 280" preserveAspectRatio="none">
                  {/* Grid Lines */}
                  <line x1="50" y1="140" x2="780" y2="140" stroke="rgba(255,255,255,0.25)" strokeDasharray="3 3" />
                  
                  {/* Threshold Envelope Lines */}
                  <line x1="50" y1="90" x2="780" y2="90" stroke="rgba(251, 191, 36, 0.4)" strokeDasharray="2 2" />
                  <line x1="50" y1="190" x2="780" y2="190" stroke="rgba(251, 191, 36, 0.4)" strokeDasharray="2 2" />

                  {/* Y Axis Labels */}
                  <text x="5" y="40" fill="#94a3b8" fontSize="10" fontFamily="monospace">+{ (threshold * 2).toFixed(3) } mm</text>
                  <text x="5" y="93" fill="#fbbf24" fontSize="9" fontFamily="monospace">+{ threshold.toFixed(3) } mm</text>
                  <text x="5" y="144" fill="#94a3b8" fontSize="10" fontFamily="monospace"> 0.000 mm</text>
                  <text x="5" y="193" fill="#fbbf24" fontSize="9" fontFamily="monospace">-{ threshold.toFixed(3) } mm</text>
                  <text x="5" y="250" fill="#94a3b8" fontSize="10" fontFamily="monospace">-{ (threshold * 2).toFixed(3) } mm</text>

                  {/* Polyline dx (Red) */}
                  <polyline
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={points.map((pt, i) => {
                      const x = 50 + (i / Math.max(1, points.length - 1)) * 720;
                      const y = 140 - (pt.dx / (threshold * 2 || 0.02)) * 100;
                      return `${x},${Math.max(20, Math.min(260, y))}`;
                    }).join(' ')}
                  />

                  {/* Polyline dy (Green) */}
                  <polyline
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={points.map((pt, i) => {
                      const x = 50 + (i / Math.max(1, points.length - 1)) * 720;
                      const y = 140 - (pt.dy / (threshold * 2 || 0.02)) * 100;
                      return `${x},${Math.max(20, Math.min(260, y))}`;
                    }).join(' ')}
                  />

                  {/* Polyline dz (Sky Blue) */}
                  <polyline
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={points.map((pt, i) => {
                      const x = 50 + (i / Math.max(1, points.length - 1)) * 720;
                      const y = 140 - (pt.dz / (threshold * 2 || 0.02)) * 100;
                      return `${x},${Math.max(20, Math.min(260, y))}`;
                    }).join(' ')}
                  />

                  {/* Point circles */}
                  {points.map((pt, i) => {
                    const x = 50 + (i / Math.max(1, points.length - 1)) * 720;
                    const yX = Math.max(20, Math.min(260, 140 - (pt.dx / (threshold * 2 || 0.02)) * 100));
                    const yY = Math.max(20, Math.min(260, 140 - (pt.dy / (threshold * 2 || 0.02)) * 100));
                    const yZ = Math.max(20, Math.min(260, 140 - (pt.dz / (threshold * 2 || 0.02)) * 100));
                    const isSelected = selectedPointIndex === i;

                    return (
                      <g key={i} className="cursor-pointer" onClick={() => setSelectedPointIndex(i)}>
                        <circle cx={x} cy={yX} r={isSelected ? "5" : "3"} fill="#ef4444" stroke="#ffffff" strokeWidth="1" />
                        <circle cx={x} cy={yY} r={isSelected ? "5" : "3"} fill="#10b981" stroke="#ffffff" strokeWidth="1" />
                        <circle cx={x} cy={yZ} r={isSelected ? "5" : "3"} fill="#38bdf8" stroke="#ffffff" strokeWidth="1" />
                      </g>
                    );
                  })}
                </svg>

                {/* X Axis Angles labels */}
                <div className="absolute bottom-1 left-12 right-6 flex justify-between text-[15px] font-mono-num text-slate-400 pointer-events-none">
                  {points.filter((_, i) => i === 0 || i === Math.floor(points.length / 2) || i === points.length - 1).map((pt, i) => (
                    <span key={i}>{pt.angle.toFixed(1)}°</span>
                  ))}
                </div>
              </InteractiveCurveBox>

              {/* Selected Point Inspector Footer */}
              {points[selectedPointIndex] && (
                <div 
                  className="px-3 py-1.5 rounded border flex items-center justify-between text-xs shrink-0 font-mono-num"
                  style={{
                    backgroundColor: tokens.subcardBg,
                    borderColor: tokens.dividerColor,
                  }}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-bold" style={{ color: tokens.titleColor }}>
                      选中点 #{points[selectedPointIndex].index} ({points[selectedPointIndex].angle.toFixed(1)}°)
                    </span>
                    <span>X: {points[selectedPointIndex].x.toFixed(4)}</span>
                    <span>Y: {points[selectedPointIndex].y.toFixed(4)}</span>
                    <span>Z: {points[selectedPointIndex].z.toFixed(4)}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-rose-400 font-semibold">dx: {points[selectedPointIndex].dx >= 0 ? `+${points[selectedPointIndex].dx.toFixed(4)}` : points[selectedPointIndex].dx.toFixed(4)}</span>
                    <span className="text-emerald-400 font-semibold">dy: {points[selectedPointIndex].dy >= 0 ? `+${points[selectedPointIndex].dy.toFixed(4)}` : points[selectedPointIndex].dy.toFixed(4)}</span>
                    <span className="text-sky-400 font-semibold">dz: {points[selectedPointIndex].dz >= 0 ? `+${points[selectedPointIndex].dz.toFixed(4)}` : points[selectedPointIndex].dz.toFixed(4)}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Fixed Narrow (~250px) with Real-time Sensor Data & Operation Buttons */}
        <div className="w-60 shrink-0 flex flex-col gap-3 overflow-y-auto">
          {/* Card 1: 传感器测量数据 */}
          <div 
            className="rounded-lg border p-3 flex flex-col gap-2 transition-colors shadow-sm"
            style={{
              backgroundColor: tokens.cardBg,
              borderColor: tokens.borderColor,
            }}
          >
            <div 
              className="flex items-center justify-between pb-1.5 border-b"
              style={{ borderColor: tokens.dividerColor }}
            >
              <span className="text-xs font-bold tracking-wide font-sans" style={{ color: tokens.titleColor }}>
                传感器实时数据
              </span>
              <span className="text-[15px] font-mono-num" style={{ color: tokens.mutedColor }}>
                实时
              </span>
            </div>

            {/* L1, L2, L3 */}
            <div className="space-y-1.5 font-mono-num text-xs">
              <div 
                className="flex items-center justify-between px-2 py-1 rounded border"
                style={{
                  backgroundColor: tokens.subcardBg,
                  borderColor: tokens.borderColor,
                }}
              >
                <span className="text-pink-400 font-bold">L1:</span>
                <span className="font-semibold" style={{ color: tokens.titleColor }}>
                  {sensorData.l1.toFixed(4)} mm
                </span>
              </div>
              <div 
                className="flex items-center justify-between px-2 py-1 rounded border"
                style={{
                  backgroundColor: tokens.subcardBg,
                  borderColor: tokens.borderColor,
                }}
              >
                <span className="text-purple-400 font-bold">L2:</span>
                <span className="font-semibold" style={{ color: tokens.titleColor }}>
                  {sensorData.l2.toFixed(4)} mm
                </span>
              </div>
              <div 
                className="flex items-center justify-between px-2 py-1 rounded border"
                style={{
                  backgroundColor: tokens.subcardBg,
                  borderColor: tokens.borderColor,
                }}
              >
                <span className="text-cyan-400 font-bold">L3:</span>
                <span className="font-semibold" style={{ color: tokens.titleColor }}>
                  {sensorData.l3.toFixed(4)} mm
                </span>
              </div>
            </div>

            {/* 球心坐标 X, Y, Z */}
            <div className="pt-2 border-t" style={{ borderColor: tokens.dividerColor }}>
              <span className="text-[17px] block mb-1 font-medium" style={{ color: tokens.mutedColor }}>
                球心坐标 (mm):
              </span>
              <div className="grid grid-cols-3 gap-1 font-mono-num text-[17px] text-center">
                <div 
                  className="px-1 py-1 rounded border text-sky-400 font-bold"
                  style={{
                    backgroundColor: tokens.subcardBg,
                    borderColor: tokens.borderColor,
                  }}
                >
                  {sensorData.x.toFixed(3)}
                </div>
                <div 
                  className="px-1 py-1 rounded border text-emerald-400 font-bold"
                  style={{
                    backgroundColor: tokens.subcardBg,
                    borderColor: tokens.borderColor,
                  }}
                >
                  {sensorData.y.toFixed(3)}
                </div>
                <div 
                  className="px-1 py-1 rounded border text-amber-400 font-bold"
                  style={{
                    backgroundColor: tokens.subcardBg,
                    borderColor: tokens.borderColor,
                  }}
                >
                  {sensorData.z.toFixed(3)}
                </div>
              </div>
            </div>

            {/* Confirm Origin Button */}
            <button
              onClick={recordOrigin}
              className={`mt-1 w-full py-1.5 px-2 rounded text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${tokens.secondaryButtonClass}`}
            >
              <Target className="w-3.5 h-3.5 text-sky-400" />
              <span>确定原点</span>
            </button>
          </div>

          {/* Card 2: 操作按钮竖排 6 钮 */}
          <div 
            className="rounded-lg border p-3 flex flex-col gap-2 transition-colors shadow-sm"
            style={{
              backgroundColor: tokens.cardBg,
              borderColor: tokens.borderColor,
            }}
          >
            <div 
              className="pb-1.5 border-b text-xs font-bold font-sans"
              style={{ 
                borderColor: tokens.dividerColor,
                color: tokens.titleColor 
              }}
            >
              操作按钮
            </div>

            {/* 1. 导出 NC 程序 */}
            <button
              onClick={handleExportNC}
              className={`w-full py-2 px-3 rounded text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer ${tokens.secondaryButtonClass}`}
            >
              <FileCode className="w-3.5 h-3.5 text-sky-400" />
              <span>导出 NC 程序</span>
            </button>

            {/* 2. 自动测量 (Primary Emphasized) */}
            <button
              onClick={handleStartAutoMeasure}
              className={`w-full py-2 px-3 rounded text-xs font-bold shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isAutoMeasuring
                  ? 'bg-amber-600 hover:bg-amber-500 text-white animate-pulse'
                  : 'bg-sky-600 hover:bg-sky-500 text-white'
              }`}
            >
              {isAutoMeasuring ? (
                <>
                  <Square className="w-3.5 h-3.5" />
                  <span>停止测量 (进行中...)</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>自动测量</span>
                </>
              )}
            </button>

            {/* 4. 手动测量 */}
            <button
              onClick={handleManualMeasure}
              className={`w-full py-2 px-3 rounded text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer ${tokens.secondaryButtonClass}`}
            >
              <Hand className="w-3.5 h-3.5 text-indigo-400" />
              <span>手动测量</span>
            </button>

            {/* 5. 保存 (Green Confirm Action) */}
            <button
              onClick={() => setShowSaveModal(true)}
              className="w-full py-2 px-3 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>保存测量报告</span>
            </button>

            {/* 6. 取消 (Red Danger/Cancel Action) */}
            <button
              onClick={() => {
                showToast('已取消当前测量任务操作');
              }}
              className="w-full py-2 px-3 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>取消</span>
            </button>
          </div>
        </div>
      </div>

      {/* Save Modal Dialog */}
      {showSaveModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div 
            className="w-96 rounded-xl border p-5 shadow-2xl flex flex-col gap-4 text-xs"
            style={{
              backgroundColor: tokens.cardBg,
              borderColor: tokens.borderColor,
            }}
          >
            <div 
              className="flex items-center gap-2 font-bold text-sm pb-2 border-b"
              style={{ 
                borderColor: tokens.dividerColor,
                color: tokens.titleColor 
              }}
            >
              <Save className="w-4 h-4 text-emerald-400" />
              <span>保存测量文件</span>
            </div>

            <div className="flex flex-col gap-1.5">
              <label style={{ color: tokens.mutedColor }} className="text-xs">
                文件名称（留空按默认名保存）：
              </label>
              <input
                type="text"
                placeholder={`${machineId}_${axisName}_${new Date().toISOString().slice(0, 10)}.dat`}
                value={saveFileName}
                onChange={(e) => setSaveFileName(e.target.value)}
                className={`w-full px-3 py-2 rounded border font-mono-num text-xs ${tokens.inputClass}`}
              />
              <span className="text-[15px]" style={{ color: tokens.mutedColor }}>
                将同时归档原始 DATABLOCK 数据块与几何拟合系数
              </span>
            </div>

            <div 
              className="flex items-center justify-end gap-2 pt-2 border-t"
              style={{ borderColor: tokens.dividerColor }}
            >
              <button
                onClick={() => setShowSaveModal(false)}
                className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${tokens.secondaryButtonClass}`}
              >
                取消
              </button>
              <button
                onClick={handleSaveReport}
                className="px-4 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors cursor-pointer shadow-xs"
              >
                确定保存
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
