/**
 * NC 程序模板 —— 依据 资料《测量轨迹(2).zip》RTCP/非RTCP A/B/C 宏程序原文参数化。
 * 变量编号以 zip 模板为准（圆弧角度范围 = #6；RTCP 刀长号 = #9）。
 * 《数据验证.docx》P0 规则：界面填写的参数值直接写入对应 # 变量行。
 */

export type NcAxis = 'A轴' | 'B轴' | 'C轴';

export interface RtcpParams {
  start: number;      // #5  起始角度
  range: number;      // #6  旋转范围 deg
  interval: number;   // #7  间隔角度 deg
  dwell: number;      // #8  停留时间 s（0=不停）
  toolNo: number;     // #9  刀长号 H
  feed: number;       // #16 进给速度
}

export interface NonRtcpParams {
  arcStart1: number;  // #1  圆弧起点坐标1（A轴=Y, B轴=X, C轴=X）
  arcStart2: number;  // #2  圆弧起点坐标2（A轴=Z, B轴=Z, C轴=Y）
  center1: number;    // #4  圆心坐标1
  center2: number;    // #5  圆心坐标2
  arcRange: number;   // #6  圆弧角度范围 deg
  dwellInterval: number; // #7 停留间隔角度 deg
  dwell: number;      // #8  停留时间 s
  feed: number;       // #16 进给速度
  stepDeg: number;    // #19 点间隔角度 deg
  startAngle: number; // #25 旋转轴起始角度
  gain: number;       // #26 联动倍率（旋转轴增量=圆弧转角×#26）
}

export const DEFAULT_RTCP_PARAMS: RtcpParams = {
  start: 0, range: 360, interval: 10, dwell: 5, toolNo: 1, feed: 500,
};

export const DEFAULT_NON_RTCP_PARAMS: NonRtcpParams = {
  arcStart1: 50, arcStart2: 10, center1: 0, center2: 0,
  arcRange: 360, dwellInterval: 10, dwell: 5, feed: 500,
  stepDeg: 0.1, startAngle: 0, gain: 1,
};

/** 非 RTCP 模板随轴变化的平面/标签定义 */
export function nonRtcpAxisMeta(axis: NcAxis) {
  if (axis === 'A轴') {
    return {
      axisChar: 'A',
      plane1: 'Y', plane2: 'Z',
      label1: '圆弧起点Y坐标', label2: '圆弧起点Z坐标',
      labelC1: '圆心Y', labelC2: '圆心Z',
      comment1: '起点Y', comment2: '起点Z', commentC1: '圆心Y', commentC2: '圆心Z',
    };
  }
  if (axis === 'B轴') {
    return {
      axisChar: 'B',
      plane1: 'X', plane2: 'Z',
      label1: '圆弧起点X坐标', label2: '圆弧起点Z坐标',
      labelC1: '圆心X', labelC2: '圆心Z',
      comment1: '起点X', comment2: '起点Z', commentC1: '圆心X', commentC2: '圆心Z',
    };
  }
  return {
    axisChar: 'C',
    plane1: 'X', plane2: 'Y',
    label1: '圆弧起点X坐标', label2: '圆弧起点Y坐标',
    labelC1: '圆心X', labelC2: '圆心Y',
    comment1: '起点X', comment2: '起点Y', commentC1: '圆心X', commentC2: '圆心Y',
  };
}

const fmt = (n: number) => {
  const v = Number(n);
  return Number.isFinite(v) ? String(v) : '0';
};

/** RTCP 测量程序（模板：测量轨迹/RTCP/rtcp（A|B|C）.txt） */
export function buildRtcpProgram(axis: NcAxis, p: RtcpParams): string {
  const a = axis.replace('轴', '');
  return `O8003
G54
(RTCP ${a})
G90

#5=${fmt(p.start)}        (起始${a})
#6=${fmt(p.range)}        (旋转范围deg，正=${a}正向，负=${a}负向)
#7=${fmt(p.interval)}        (间隔deg)
#8=${fmt(p.dwell)}        (停留秒，0=不停)
#9=${fmt(p.toolNo)}          (H刀长号)
#16=${fmt(p.feed)}     (进给F)

#13=ABS[#7]
IF [#6 GE 0] GOTO10
#13=0-#13
N10
#12=#5+#6

#50=ROUND[ABS[#6]/ABS[#7]]
IF [#50 GE 1] GOTO11
#50=1
N11

G43.4 T#9
G01 ${a}#5 F#16
IF [#8 LE 0] GOTO20
G04 X#8
N20
#51=1

WHILE [#51 LE #50] DO1
  IF [#51 LT #50] GOTO30
  #20=#12
  GOTO31
  N30
  #20=#5+#51*#13
  N31
  G01 ${a}#20 F#16
  IF [#8 LE 0] GOTO40
  G04 X#8
  N40
  #51=#51+1
END1

G49
M30
`;
}

/** 非 RTCP 测量程序（模板：测量轨迹/非RTCP/非RTCP（A|B|C）.txt） */
export function buildNonRtcpProgram(axis: NcAxis, p: NonRtcpParams): string {
  const meta = nonRtcpAxisMeta(axis);
  const a = meta.axisChar;
  const p1 = meta.plane1;
  const p2 = meta.plane2;
  return `O8003 (非RTCP ${a})
G54 G90
#1=${fmt(p.arcStart1)}      (${meta.comment1})
#2=${fmt(p.arcStart2)}      (${meta.comment2})
#4=${fmt(p.center1)}       (${meta.commentC1})
#5=${fmt(p.center2)}       (${meta.commentC2})
#6=${fmt(p.arcRange)}     (${p1}${p2}圆弧角度范围deg, 正=逆时针)
#7=${fmt(p.dwellInterval)}      (停留间隔deg)
#8=${fmt(p.dwell)}        (停留秒, 0=不停)
#16=${fmt(p.feed)}    (进给F)
#19=${fmt(p.stepDeg)}      (点间隔deg)
#25=${fmt(p.startAngle)}      (${a}起始角deg)
#26=${fmt(p.gain)}      (${a}增益: ${a}增量=${p1}${p2}转角*#26)

#10=SQRT[[#1-#4]*[#1-#4]+[#2-#5]*[#2-#5]]
#11=ATAN[#2-#5]/[#1-#4]
#12=#11+#6
#13=ABS[#19]
IF [#6 GE 0] GOTO10
#13=0-#13
N10

#50=ROUND[ABS[#6]/ABS[#19]]
IF [#50 GE 1] GOTO11
#50=1
N11

#21=#4+#10*COS[#11]
#22=#5+#10*SIN[#11]

(到圆弧起点 + ${a}起始角, 若已对好则原地)
G01 ${p1}#21 ${p2}#22 ${a}#25 F#16
IF [#8 LE 0] GOTO20
G04 X#8
N20
#32=0
#51=1

WHILE [#51 LE #50] DO1
  IF [#51 LT #50] GOTO30
  #20=#12
  GOTO31
  N30
  #20=#11+#51*#13
  N31
  #21=#4+#10*COS[#20]
  #22=#5+#10*SIN[#20]
  #28=#25+[#20-#11]*#26
  G01 ${p1}#21 ${p2}#22 ${a}#28 F#16
  #33=FIX[[ABS[#20-#11]+0.0001]/ABS[#7]]
  IF [#33 LE #32] GOTO40
  IF [#8 LE 0] GOTO41
  G04 X#8
  N41
  #32=#33
  N40
  #51=#51+1
END1
M30
`;
}
