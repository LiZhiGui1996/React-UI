/**
 * RealtimeStore —— 实时数据独立存储（订阅制，非 React State）
 *
 * 设计目标（性能优化任务书）：
 * 1. Qt 每帧数据只写入 ring buffer（O(1)，无数组重建）
 * 2. 采集频率与 UI 渲染频率彻底分离：store 内部 150ms 节流通知
 * 3. 只有调用 useRealtime() 的组件（实时页面）随数据重渲染，
 *    TitleBar/Sidebar/报表等无关组件不再每帧重渲染
 * 4. 桥只保留一条正式数据路径：qt-bridge → pushRealtimeFrame
 */
import { useSyncExternalStore } from 'react';

export interface RealtimeSensor {
  u1: number; u2: number; u3: number;
  l1: number; l2: number; l3: number;
  x: number; y: number; z: number;
}

export interface VoltPoint { time: number; u1: number; u2: number; u3: number }
export interface DispPoint { time: number; l1: number; l2: number; l3: number; x: number; y: number; z: number }

const VOLT_CAP = 60;
const DISP_CAP = 60;
const NOTIFY_MS = 150;          // UI 快照节流（采集 100ms 不受影响）

/* 初始历史（60 点正弦底噪，与旧 mock 形状一致） */
function seedDisp(): DispPoint[] {
  const out: DispPoint[] = [];
  for (let i = 0; i < VOLT_CAP; i++) {
    const t = i * 0.1;
    out.push({
      time: Number(t.toFixed(1)),
      l1: Number((2.0 + 0.02 * Math.sin(t)).toFixed(4)),
      l2: Number((1.9 + 0.02 * Math.cos(t)).toFixed(4)),
      l3: Number((2.1 + 0.02 * Math.sin(2 * t)).toFixed(4)),
      x: 0, y: 0, z: 0,
    });
  }
  return out;
}
function seedVolt(): VoltPoint[] {
  const out: VoltPoint[] = [];
  for (let i = 0; i < VOLT_CAP; i++) {
    const t = i * 0.1;
    out.push({
      time: Number(t.toFixed(1)),
      u1: Number((2.0 + 0.08 * Math.sin(t)).toFixed(4)),
      u2: Number((2.0 + 0.08 * Math.cos(t)).toFixed(4)),
      u3: Number((2.0 + 0.08 * Math.sin(2 * t)).toFixed(4)),
    });
  }
  return out;
}

let sensor: RealtimeSensor = {
  u1: 2.0, u2: 2.0, u3: 2.0, l1: 0.5, l2: 0.5, l3: 0.5, x: 0, y: 0, z: 0,
};
let voltage: VoltPoint[] = seedVolt();
let displacement: DispPoint[] = seedDisp();
let sampleCount = 0;

const listeners = new Set<() => void>();
let version = 0;
let notifyTimer: ReturnType<typeof setTimeout> | null = null;

function notifyThrottled() {
  if (notifyTimer) return;
  notifyTimer = setTimeout(() => {
    notifyTimer = null;
    version++;
    listeners.forEach((l) => l());
  }, NOTIFY_MS);
}

/** 桥每帧调用：只写 buffer + 节流通知（无 React State） */
export function pushRealtimeFrame(d: {
  u1: number; u2: number; u3: number;
  l1: number; l2: number; l3: number;
}) {
  const nU1 = Number(d.u1.toFixed(4));
  const nU2 = Number(d.u2.toFixed(4));
  const nU3 = Number(d.u3.toFixed(4));
  const nL1 = Number(d.l1.toFixed(4));
  const nL2 = Number(d.l2.toFixed(4));
  const nL3 = Number(d.l3.toFixed(4));

  const lastV = voltage[voltage.length - 1];
  const now = Number(((lastV?.time || 0) + 0.1).toFixed(1));

  sensor = {
    u1: nU1, u2: nU2, u3: nU3,
    l1: nL1, l2: nL2, l3: nL3,
    x: Number((nL1 - (voltage === undefined ? 0 : 0.5) + (sensor.x || 0) * 0).toFixed(4)) || sensor.x,
    y: sensor.y, z: sensor.z,
  };

  voltage = [...voltage.slice(-(VOLT_CAP - 1)), { time: now, u1: nU1, u2: nU2, u3: nU3 }];
  displacement = [...displacement.slice(-(DISP_CAP - 1)), {
    time: now, l1: nL1, l2: nL2, l3: nL3, x: sensor.x, y: sensor.y, z: sensor.z,
  }];
  sampleCount++;
  notifyThrottled();
}

/** 订阅（useSyncExternalStore 用）；返回快照版本号 */
export function subscribeRealtime(l: () => void): () => void {
  listeners.add(l);
  return () => listeners.delete(l);
}
export function getSensor(): RealtimeSensor {
  return sensor;
}
export function getRealtimeVersion(): number {
  return version;
}

/** React 订阅 hook：只有调用它的组件随实时数据重渲染 */
export function useRealtime() {
  useSyncExternalStore(subscribeRealtime, getRealtimeVersion, getRealtimeVersion);
  return {
    sensorData: sensor,
    voltageHistory: voltage,
    displacementHistory: displacement,
    sampleCount,
  };
}
